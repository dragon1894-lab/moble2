﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelDeckA = new Panel();
            btnLoadA = new Button();
            lblSongA = new Label();
            lblTimeA = new Label();
            btnPlayA = new Button();
            btnPauseA = new Button();
            btnStopA = new Button();
            trackPositionA = new TrackBar();
            trackVolumeA = new TrackBar();
            timerA = new System.Windows.Forms.Timer(components);
            panelDeckB = new Panel();
            btnLoadB = new Button();
            lblSongB = new Label();
            lblTimeB = new Label();
            trackPositionB = new TrackBar();
            btnPauseB = new Button();
            btnPlayB = new Button();
            btnStopB = new Button();
            trackVolumeB = new TrackBar();
            numMasterBpm = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)trackPositionA).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackVolumeA).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackPositionB).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackVolumeB).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numMasterBpm).BeginInit();
            SuspendLayout();
            // 
            // panelDeckA
            // 
            panelDeckA.AllowDrop = true;
            panelDeckA.Location = new Point(36, 47);
            panelDeckA.Name = "panelDeckA";
            panelDeckA.Size = new Size(307, 192);
            panelDeckA.TabIndex = 0;
            panelDeckA.DragDrop += panelDeckA_DragDrop;
            panelDeckA.DragEnter += panelDeckA_DragEnter;
            // 
            // btnLoadA
            // 
            btnLoadA.Location = new Point(36, 18);
            btnLoadA.Name = "btnLoadA";
            btnLoadA.Size = new Size(75, 23);
            btnLoadA.TabIndex = 1;
            btnLoadA.Text = "📁 곡 선택";
            btnLoadA.UseVisualStyleBackColor = true;
            btnLoadA.Click += btnLoadA_Click;
            // 
            // lblSongA
            // 
            lblSongA.AutoSize = true;
            lblSongA.Location = new Point(182, 26);
            lblSongA.Name = "lblSongA";
            lblSongA.Size = new Size(0, 15);
            lblSongA.TabIndex = 2;
            // 
            // lblTimeA
            // 
            lblTimeA.AutoSize = true;
            lblTimeA.Location = new Point(261, 293);
            lblTimeA.Name = "lblTimeA";
            lblTimeA.Size = new Size(82, 15);
            lblTimeA.TabIndex = 3;
            lblTimeA.Text = "00:00 / 00:00";
            // 
            // btnPlayA
            // 
            btnPlayA.Location = new Point(145, 289);
            btnPlayA.Name = "btnPlayA";
            btnPlayA.Size = new Size(31, 23);
            btnPlayA.TabIndex = 4;
            btnPlayA.Text = "▶";
            btnPlayA.UseVisualStyleBackColor = true;
            btnPlayA.Click += btnPlayA_Click;
            // 
            // btnPauseA
            // 
            btnPauseA.Location = new Point(108, 289);
            btnPauseA.Name = "btnPauseA";
            btnPauseA.Size = new Size(31, 23);
            btnPauseA.TabIndex = 5;
            btnPauseA.Text = "⏸";
            btnPauseA.UseVisualStyleBackColor = true;
            btnPauseA.Click += btnPauseA_Click;
            // 
            // btnStopA
            // 
            btnStopA.Location = new Point(182, 289);
            btnStopA.Name = "btnStopA";
            btnStopA.Size = new Size(31, 23);
            btnStopA.TabIndex = 6;
            btnStopA.Text = "■";
            btnStopA.UseVisualStyleBackColor = true;
            btnStopA.Click += btnStopA_Click;
            // 
            // trackPositionA
            // 
            trackPositionA.Location = new Point(36, 245);
            trackPositionA.Maximum = 100;
            trackPositionA.Name = "trackPositionA";
            trackPositionA.Size = new Size(307, 45);
            trackPositionA.TabIndex = 7;
            trackPositionA.TickStyle = TickStyle.None;
            trackPositionA.Value = 100;
            // 
            // trackVolumeA
            // 
            trackVolumeA.Location = new Point(349, 47);
            trackVolumeA.Maximum = 100;
            trackVolumeA.Name = "trackVolumeA";
            trackVolumeA.Orientation = Orientation.Vertical;
            trackVolumeA.Size = new Size(45, 192);
            trackVolumeA.TabIndex = 8;
            trackVolumeA.TickStyle = TickStyle.TopLeft;
            trackVolumeA.Value = 100;
            trackVolumeA.Scroll += trackVolumeA_Scroll;
            // 
            // timerA
            // 
            timerA.Enabled = true;
            // 
            // panelDeckB
            // 
            panelDeckB.Location = new Point(415, 47);
            panelDeckB.Name = "panelDeckB";
            panelDeckB.Size = new Size(307, 192);
            panelDeckB.TabIndex = 9;
            // 
            // btnLoadB
            // 
            btnLoadB.Location = new Point(415, 18);
            btnLoadB.Name = "btnLoadB";
            btnLoadB.Size = new Size(75, 23);
            btnLoadB.TabIndex = 10;
            btnLoadB.Text = "📁 곡 선택";
            btnLoadB.UseVisualStyleBackColor = true;
            // 
            // lblSongB
            // 
            lblSongB.AutoSize = true;
            lblSongB.Location = new Point(584, 22);
            lblSongB.Name = "lblSongB";
            lblSongB.Size = new Size(0, 15);
            lblSongB.TabIndex = 11;
            // 
            // lblTimeB
            // 
            lblTimeB.AutoSize = true;
            lblTimeB.Location = new Point(640, 293);
            lblTimeB.Name = "lblTimeB";
            lblTimeB.Size = new Size(82, 15);
            lblTimeB.TabIndex = 12;
            lblTimeB.Text = "00:00 / 00:00";
            // 
            // trackPositionB
            // 
            trackPositionB.Location = new Point(415, 245);
            trackPositionB.Maximum = 100;
            trackPositionB.Name = "trackPositionB";
            trackPositionB.Size = new Size(307, 45);
            trackPositionB.TabIndex = 13;
            trackPositionB.TickStyle = TickStyle.None;
            // 
            // btnPauseB
            // 
            btnPauseB.Location = new Point(516, 289);
            btnPauseB.Name = "btnPauseB";
            btnPauseB.Size = new Size(31, 23);
            btnPauseB.TabIndex = 14;
            btnPauseB.Text = "⏸";
            btnPauseB.UseVisualStyleBackColor = true;
            // 
            // btnPlayB
            // 
            btnPlayB.Location = new Point(553, 289);
            btnPlayB.Name = "btnPlayB";
            btnPlayB.Size = new Size(31, 23);
            btnPlayB.TabIndex = 15;
            btnPlayB.Text = "▶";
            btnPlayB.UseVisualStyleBackColor = true;
            // 
            // btnStopB
            // 
            btnStopB.Location = new Point(590, 289);
            btnStopB.Name = "btnStopB";
            btnStopB.Size = new Size(31, 23);
            btnStopB.TabIndex = 16;
            btnStopB.Text = "■";
            btnStopB.UseVisualStyleBackColor = true;
            // 
            // trackVolumeB
            // 
            trackVolumeB.Location = new Point(742, 47);
            trackVolumeB.Maximum = 100;
            trackVolumeB.Name = "trackVolumeB";
            trackVolumeB.Orientation = Orientation.Vertical;
            trackVolumeB.Size = new Size(45, 192);
            trackVolumeB.TabIndex = 17;
            trackVolumeB.TickStyle = TickStyle.TopLeft;
            trackVolumeB.Value = 100;
            // 
            // numMasterBpm
            // 
            numMasterBpm.Location = new Point(316, 358);
            numMasterBpm.Maximum = new decimal(new int[] { 200, 0, 0, 0 });
            numMasterBpm.Minimum = new decimal(new int[] { 50, 0, 0, 0 });
            numMasterBpm.Name = "numMasterBpm";
            numMasterBpm.Size = new Size(120, 23);
            numMasterBpm.TabIndex = 18;
            numMasterBpm.Value = new decimal(new int[] { 120, 0, 0, 0 });
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(847, 450);
            Controls.Add(numMasterBpm);
            Controls.Add(trackVolumeB);
            Controls.Add(btnStopB);
            Controls.Add(btnPlayB);
            Controls.Add(btnPauseB);
            Controls.Add(trackPositionB);
            Controls.Add(lblTimeB);
            Controls.Add(lblSongB);
            Controls.Add(btnLoadB);
            Controls.Add(panelDeckB);
            Controls.Add(trackVolumeA);
            Controls.Add(trackPositionA);
            Controls.Add(btnStopA);
            Controls.Add(btnPauseA);
            Controls.Add(btnPlayA);
            Controls.Add(lblTimeA);
            Controls.Add(lblSongA);
            Controls.Add(btnLoadA);
            Controls.Add(panelDeckA);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)trackPositionA).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackVolumeA).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackPositionB).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackVolumeB).EndInit();
            ((System.ComponentModel.ISupportInitialize)numMasterBpm).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelDeckA;
        private Button btnLoadA;
        private Label lblSongA;
        private Label lblTimeA;
        private Button btnPlayA;
        private Button btnPauseA;
        private Button btnStopA;
        private TrackBar trackPositionA;
        private TrackBar trackVolumeA;
        private System.Windows.Forms.Timer timerA;
        private Panel panelDeckB;
        private Button btnLoadB;
        private Label lblSongB;
        private Label lblTimeB;
        private TrackBar trackPositionB;
        private Button btnPauseB;
        private Button btnPlayB;
        private Button btnStopB;
        private TrackBar trackVolumeB;
        private NumericUpDown numMasterBpm;
    }
}
