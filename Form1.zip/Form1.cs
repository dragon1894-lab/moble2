using System;
using System.IO;
using System.Windows.Forms;
using NAudio.Wave;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        // Deck A ����� ���� ����
        private AudioFileReader audioFileA;
        private SpeedSampleProvider speedProviderA;
        private DirectSoundOut waveOutA;
        private bool isDraggingPositionA = false;
        private float baseBpmA = 120.0f; // Deck A �⺻ ���� BPM

        // Deck B ����� ���� ����
        private AudioFileReader audioFileB;
        private SpeedSampleProvider speedProviderB;
        private DirectSoundOut waveOutB;
        private bool isDraggingPositionB = false;
        private float baseBpmB = 120.0f; // Deck B �⺻ ���� BPM

        public Form1()
        {
            InitializeComponent();

            // 1. �巡�� �� ��� ����
            if (panelDeckA != null) RegisterDragDrop(panelDeckA, panelDeckA_DragEnter, panelDeckA_DragDrop);
            if (panelDeckB != null) RegisterDragDrop(panelDeckB, panelDeckB_DragEnter, panelDeckB_DragDrop);

            // 2. Deck A & Deck B �̺�Ʈ ����
            InitDeckAEvents();
            InitDeckBEvents();

            // 3. �߾� ������ BPM �̺�Ʈ ���� (NumericUpDown ��Ʈ��)
            if (numMasterBpm != null)
            {
                numMasterBpm.ValueChanged -= numMasterBpm_ValueChanged;
                numMasterBpm.ValueChanged += numMasterBpm_ValueChanged;
            }

            // 4. Ÿ�̸� ���� (ȭ�� �ǽð� ������Ʈ)
            if (timerA != null)
            {
                timerA.Interval = 100;
                timerA.Tick -= timer_Tick;
                timerA.Tick += timer_Tick;
                timerA.Start();
            }
        }

        // --- �г� ���� ��Ʈ�ѱ��� �巡�� �� ��� ���� ��� ---
        private void RegisterDragDrop(Control control, DragEventHandler enterHandler, DragEventHandler dropHandler)
        {
            control.AllowDrop = true;
            control.DragEnter -= enterHandler;
            control.DragEnter += enterHandler;
            control.DragDrop -= dropHandler;
            control.DragDrop += dropHandler;

            foreach (Control child in control.Controls)
            {
                RegisterDragDrop(child, enterHandler, dropHandler);
            }
        }

        // ==========================================
        // �� [�߾� ������ BPM] ��ġ ���� �̺�Ʈ
        // ==========================================
        private void numMasterBpm_ValueChanged(object sender, EventArgs e)
        {
            float targetBpm = (float)numMasterBpm.Value;

            // ������ BPM ���� �� Deck A�� Deck B�� ���ÿ� �ǽð� �ӵ� ����
            ApplyBpmToDeckA(targetBpm);
            ApplyBpmToDeckB(targetBpm);
        }

        private void ApplyBpmToDeckA(float targetBpm)
        {
            if (speedProviderA == null || baseBpmA <= 0) return;
            // ���� ��� (��: ������ 128 / �⺻ 120 = 1.0667���)
            speedProviderA.PlaybackRate = targetBpm / baseBpmA;
        }

        private void ApplyBpmToDeckB(float targetBpm)
        {
            if (speedProviderB == null || baseBpmB <= 0) return;
            speedProviderB.PlaybackRate = targetBpm / baseBpmB;
        }

        #region --- Deck A ���� ---

        private void InitDeckAEvents()
        {
            if (btnLoadA != null) { btnLoadA.Click -= btnLoadA_Click; btnLoadA.Click += btnLoadA_Click; }
            if (btnPlayA != null) { btnPlayA.Click -= btnPlayA_Click; btnPlayA.Click += btnPlayA_Click; }
            if (btnPauseA != null) { btnPauseA.Click -= btnPauseA_Click; btnPauseA.Click += btnPauseA_Click; }
            if (btnStopA != null) { btnStopA.Click -= btnStopA_Click; btnStopA.Click += btnStopA_Click; }
            if (trackVolumeA != null) { trackVolumeA.Scroll -= trackVolumeA_Scroll; trackVolumeA.Scroll += trackVolumeA_Scroll; }
            if (trackPositionA != null)
            {
                trackPositionA.MouseDown -= trackPositionA_MouseDown;
                trackPositionA.MouseDown += trackPositionA_MouseDown;
                trackPositionA.MouseUp -= trackPositionA_MouseUp;
                trackPositionA.MouseUp += trackPositionA_MouseUp;
            }
        }

        private void LoadTrackA(string filePath)
        {
            try
            {
                waveOutA?.Stop();
                audioFileA?.Dispose();
                waveOutA?.Dispose();

                // 1. ����� ���� �ε�
                audioFileA = new AudioFileReader(filePath);

                // 2. �ӵ�(BPM) ���� ���� ����
                speedProviderA = new SpeedSampleProvider(audioFileA.ToSampleProvider());

                // 3. ���� ī�� ����Ŀ ��� ����
                waveOutA = new DirectSoundOut();
                waveOutA.Init(speedProviderA);

                // 4. �ʱ� ���� �� ���� ������ ������ BPM ����
                UpdateVolumeA();
                if (numMasterBpm != null) ApplyBpmToDeckA((float)numMasterBpm.Value);

                if (lblSongA != null) lblSongA.Text = Path.GetFileName(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Deck A �ε� ����: {ex.Message}");
            }
        }

        private void btnLoadA_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Deck A ���� ���� ����";
                dialog.Filter = "���� ���� (*.mp3;*.wav;*.flac)|*.mp3;*.wav;*.flac|��� ���� (*.*)|*.*";
                if (dialog.ShowDialog() == DialogResult.OK) LoadTrackA(dialog.FileName);
            }
        }

        private void panelDeckA_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
            else e.Effect = DragDropEffects.None;
        }

        private void panelDeckA_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files != null && files.Length > 0)
            {
                string ext = Path.GetExtension(files[0]).ToLower();
                if (ext == ".mp3" || ext == ".wav" || ext == ".flac")
                {
                    LoadTrackA(files[0]);
                }
            }
        }

        private void btnPlayA_Click(object sender, EventArgs e)
        {
            if (audioFileA == null || waveOutA == null) return;
            if (audioFileA.Position >= audioFileA.Length) audioFileA.Position = 0;
            waveOutA.Play();
        }

        private void btnPauseA_Click(object sender, EventArgs e) => waveOutA?.Pause();

        private void btnStopA_Click(object sender, EventArgs e)
        {
            if (waveOutA != null && audioFileA != null)
            {
                waveOutA.Stop();
                audioFileA.Position = 0;
            }
        }

        private void trackVolumeA_Scroll(object sender, EventArgs e) => UpdateVolumeA();

        private void UpdateVolumeA()
        {
            if (audioFileA != null && trackVolumeA != null)
                audioFileA.Volume = trackVolumeA.Value / 100.0f;
        }

        private void trackPositionA_MouseDown(object sender, MouseEventArgs e) => isDraggingPositionA = true;

        private void trackPositionA_MouseUp(object sender, MouseEventArgs e)
        {
            if (audioFileA != null && trackPositionA != null && audioFileA.TotalTime.TotalSeconds > 0)
            {
                double targetSeconds = (trackPositionA.Value / 100.0) * audioFileA.TotalTime.TotalSeconds;
                audioFileA.CurrentTime = TimeSpan.FromSeconds(targetSeconds);
            }
            isDraggingPositionA = false;
        }

        #endregion

        #region --- Deck B ���� ---

        private void InitDeckBEvents()
        {
            if (btnLoadB != null) { btnLoadB.Click -= btnLoadB_Click; btnLoadB.Click += btnLoadB_Click; }
            if (btnPlayB != null) { btnPlayB.Click -= btnPlayB_Click; btnPlayB.Click += btnPlayB_Click; }
            if (btnPauseB != null) { btnPauseB.Click -= btnPauseB_Click; btnPauseB.Click += btnPauseB_Click; }
            if (btnStopB != null) { btnStopB.Click -= btnStopB_Click; btnStopB.Click += btnStopB_Click; }
            if (trackVolumeB != null) { trackVolumeB.Scroll -= trackVolumeB_Scroll; trackVolumeB.Scroll += trackVolumeB_Scroll; }
            if (trackPositionB != null)
            {
                trackPositionB.MouseDown -= trackPositionB_MouseDown;
                trackPositionB.MouseDown += trackPositionB_MouseDown;
                trackPositionB.MouseUp -= trackPositionB_MouseUp;
                trackPositionB.MouseUp += trackPositionB_MouseUp;
            }
        }

        private void LoadTrackB(string filePath)
        {
            try
            {
                waveOutB?.Stop();
                audioFileB?.Dispose();
                waveOutB?.Dispose();

                audioFileB = new AudioFileReader(filePath);
                speedProviderB = new SpeedSampleProvider(audioFileB.ToSampleProvider());

                waveOutB = new DirectSoundOut();
                waveOutB.Init(speedProviderB);

                UpdateVolumeB();
                if (numMasterBpm != null) ApplyBpmToDeckB((float)numMasterBpm.Value);

                if (lblSongB != null) lblSongB.Text = Path.GetFileName(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Deck B �ε� ����: {ex.Message}");
            }
        }

        private void btnLoadB_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Deck B ���� ���� ����";
                dialog.Filter = "���� ���� (*.mp3;*.wav;*.flac)|*.mp3;*.wav;*.flac|��� ���� (*.*)|*.*";
                if (dialog.ShowDialog() == DialogResult.OK) LoadTrackB(dialog.FileName);
            }
        }

        private void panelDeckB_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
            else e.Effect = DragDropEffects.None;
        }

        private void panelDeckB_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files != null && files.Length > 0)
            {
                string ext = Path.GetExtension(files[0]).ToLower();
                if (ext == ".mp3" || ext == ".wav" || ext == ".flac")
                {
                    LoadTrackB(files[0]);
                }
            }
        }

        private void btnPlayB_Click(object sender, EventArgs e)
        {
            if (audioFileB == null || waveOutB == null) return;
            if (audioFileB.Position >= audioFileB.Length) audioFileB.Position = 0;
            waveOutB.Play();
        }

        private void btnPauseB_Click(object sender, EventArgs e) => waveOutB?.Pause();

        private void btnStopB_Click(object sender, EventArgs e)
        {
            if (waveOutB != null && audioFileB != null)
            {
                waveOutB.Stop();
                audioFileB.Position = 0;
            }
        }

        private void trackVolumeB_Scroll(object sender, EventArgs e) => UpdateVolumeB();

        private void UpdateVolumeB()
        {
            if (audioFileB != null && trackVolumeB != null)
                audioFileB.Volume = trackVolumeB.Value / 100.0f;
        }

        private void trackPositionB_MouseDown(object sender, MouseEventArgs e) => isDraggingPositionB = true;

        private void trackPositionB_MouseUp(object sender, MouseEventArgs e)
        {
            if (audioFileB != null && trackPositionB != null && audioFileB.TotalTime.TotalSeconds > 0)
            {
                double targetSeconds = (trackPositionB.Value / 100.0) * audioFileB.TotalTime.TotalSeconds;
                audioFileB.CurrentTime = TimeSpan.FromSeconds(targetSeconds);
            }
            isDraggingPositionB = false;
        }

        #endregion

        // --- ���� Ÿ�̸� (ȭ�� ��� ���� �ǽð� ������Ʈ) ---
        private void timer_Tick(object sender, EventArgs e)
        {
            if (audioFileA != null)
            {
                TimeSpan currentA = audioFileA.CurrentTime;
                TimeSpan totalA = audioFileA.TotalTime;
                if (lblTimeA != null) lblTimeA.Text = $"{currentA:mm\\:ss} / {totalA:mm\\:ss}";

                if (!isDraggingPositionA && trackPositionA != null && totalA.TotalSeconds > 0)
                {
                    double percentA = (currentA.TotalSeconds / totalA.TotalSeconds) * 100.0;
                    trackPositionA.Value = Math.Min(100, Math.Max(0, (int)percentA));
                }
            }

            if (audioFileB != null)
            {
                TimeSpan currentB = audioFileB.CurrentTime;
                TimeSpan totalB = audioFileB.TotalTime;
                if (lblTimeB != null) lblTimeB.Text = $"{currentB:mm\\:ss} / {totalB:mm\\:ss}";

                if (!isDraggingPositionB && trackPositionB != null && totalB.TotalSeconds > 0)
                {
                    double percentB = (currentB.TotalSeconds / totalB.TotalSeconds) * 100.0;
                    trackPositionB.Value = Math.Min(100, Math.Max(0, (int)percentB));
                }
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            timerA?.Stop();

            audioFileA?.Dispose();
            waveOutA?.Dispose();

            audioFileB?.Dispose();
            waveOutB?.Dispose();

            base.OnFormClosing(e);
        }
    }

    // ==========================================
    // �� �ǽð� ���� �ӵ�(BPM) ���� ���� Ŭ����
    // ==========================================
    public class SpeedSampleProvider : ISampleProvider
    {
        private readonly ISampleProvider source;
        private float playbackRate = 1.0f;

        public SpeedSampleProvider(ISampleProvider source)
        {
            this.source = source;
            this.WaveFormat = source.WaveFormat;
        }

        public WaveFormat WaveFormat { get; }

        public float PlaybackRate
        {
            get => playbackRate;
            set => playbackRate = Math.Max(0.5f, Math.Min(2.0f, value));
        }

        public int Read(float[] buffer, int offset, int count)
        {
            if (Math.Abs(playbackRate - 1.0f) < 0.01f)
            {
                return source.Read(buffer, offset, count);
            }

            int channels = WaveFormat.Channels;
            int framesRequested = count / channels;
            int sourceFramesNeeded = (int)Math.Ceiling(framesRequested * playbackRate) + 2;
            int sourceSamplesNeeded = sourceFramesNeeded * channels;

            float[] sourceBuffer = new float[sourceSamplesNeeded];
            int sourceSamplesRead = source.Read(sourceBuffer, 0, sourceSamplesNeeded);
            int sourceFramesRead = sourceSamplesRead / channels;

            if (sourceFramesRead == 0) return 0;

            int framesWritten = 0;
            for (int i = 0; i < framesRequested; i++)
            {
                float srcFramePos = i * playbackRate;
                int frame1 = (int)srcFramePos;
                int frame2 = frame1 + 1;
                float frac = srcFramePos - frame1;

                if (frame1 >= sourceFramesRead) break;
                if (frame2 >= sourceFramesRead) frame2 = frame1;

                for (int ch = 0; ch < channels; ch++)
                {
                    float s1 = sourceBuffer[frame1 * channels + ch];
                    float s2 = sourceBuffer[frame2 * channels + ch];
                    buffer[offset + (i * channels) + ch] = s1 + (s2 - s1) * frac;
                }
                framesWritten++;
            }

            return framesWritten * channels;
        }
    }
}